let pc;
let dataChannel;

document.getElementById('toggleTheme').onclick = () => {
  document.body.classList.toggle('dark');
};

document.getElementById('createOffer').onclick = async () => {
  pc = new RTCPeerConnection();
  dataChannel = pc.createDataChannel("fileChannel");

  setupDataChannel(dataChannel);

  pc.onicecandidate = (event) => {
    if (event.candidate === null) {
      document.getElementById('offerText').value = JSON.stringify(pc.localDescription);
    }
  };

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
};

document.getElementById('setAnswer').onclick = async () => {
  const answerText = document.getElementById('answerText').value;
  if (!answerText) return alert("Tempel Answer dulu");
  const answer = JSON.parse(answerText);
  await pc.setRemoteDescription(answer);
};

document.getElementById('sendFile').onclick = () => {
  const fileInput = document.getElementById('fileInput');
  if (!fileInput.files.length) return alert("Pilih file dulu");
  const file = fileInput.files[0];
  sendFile(file);
};

function setupDataChannel(channel) {
  channel.onopen = () => console.log("DataChannel terbuka");
  channel.onmessage = (event) => {
    if (typeof event.data === "string" && event.data.startsWith("META:")) {
      const meta = JSON.parse(event.data.replace("META:", ""));
      receiveBuffer = [];
      expectedSize = meta.size;
      fileName = meta.name;
      console.log("Menerima file:", fileName, expectedSize);
    } else if (event.data instanceof ArrayBuffer) {
      receiveBuffer.push(event.data);
      receivedSize += event.data.byteLength;
      updateProgress(receivedSize / expectedSize * 100);
      if (receivedSize >= expectedSize) {
        saveFile(receiveBuffer, fileName);
        receiveBuffer = [];
        receivedSize = 0;
      }
    }
  };
}

let receiveBuffer = [];
let receivedSize = 0;
let expectedSize = 0;
let fileName = "";

function sendFile(file) {
  const chunkSize = 16384;
  dataChannel.send("META:" + JSON.stringify({ name: file.name, size: file.size }));
  const reader = new FileReader();
  let offset = 0;

  reader.onload = (e) => {
    while (offset < e.target.result.byteLength) {
      const slice = e.target.result.slice(offset, offset + chunkSize);
      dataChannel.send(slice);
      offset += chunkSize;
    }
  };
  reader.readAsArrayBuffer(file);
}

function updateProgress(percent) {
  document.getElementById('progress').textContent = "Progress: " + percent.toFixed(2) + "%";
}

function saveFile(buffers, name) {
  const blob = new Blob(buffers);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.textContent = "Download " + name;
  document.getElementById('receivedFiles').appendChild(a);
  document.getElementById('progress').textContent = "Transfer selesai";
}
