# ShareIt Web Clone - Frontend Only

Versi ini **tanpa backend**, jadi bisa langsung dijalankan di **Acode** atau browser.

## Cara Jalankan di Acode
1. Ekstrak file ZIP ini di HP kamu.
2. Buka aplikasi Acode.
3. Open folder hasil ekstrak (`shareit_web_clone_frontend`).
4. Buka file `index.html` → tekan tombol ▶️ Run.
5. Browser akan terbuka dengan UI ShareIt Web.

## Cara Transfer File
- Perangkat A:
  1. Klik **Buat Offer** → copy teks dari `offerText`.
  2. Kirim teks ini ke perangkat B (misalnya lewat WhatsApp).

- Perangkat B:
  1. Buka halaman `index.html` juga.
  2. Paste teks Offer ke dalam `answerText` lalu klik **Set Answer**.
  3. Browser akan otomatis membuat Answer.
  4. Copy teks Answer → kirim balik ke perangkat A.

- Perangkat A:
  1. Paste Answer ke `answerText` → klik **Set Answer**.
  2. Koneksi P2P siap.

- Kirim File:
  1. Pilih file lewat **Choose File**.
  2. Klik **Kirim File**.
  3. Perangkat lain akan menerima link download.

## Catatan
- Karena tanpa server, pairing masih manual (copy-paste Offer/Answer).
- Untuk otomatisasi (QR code / discovery), butuh backend signaling server.
