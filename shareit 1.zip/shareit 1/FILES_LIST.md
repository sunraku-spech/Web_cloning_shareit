Daftar file yang termasuk dalam paket:

/
- README.md
- PROMPT_DETAILED.txt
- FILES_LIST.md
- package.json
- server.js

/public
- index.html        -> Halaman frontend utama (UI + integrasi QR + Tailwind)
- app.js            -> Logic WebRTC, Signaling, chunking, checksum, resume
- styles.css        -> Sedikit kustom CSS (menggunakan Tailwind CDN)
